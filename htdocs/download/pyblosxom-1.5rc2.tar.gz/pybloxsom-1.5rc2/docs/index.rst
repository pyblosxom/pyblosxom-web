.. PyBlosxom documentation master file, created by sphinx-quickstart on Mon Feb 16 00:26:34 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PyBlosxom's documentation!
=====================================

Contents:

.. toctree::
   :maxdepth: 2

   introduction
   about_pyblosxom
   notes/CHANGELOG
   notes/INSTALL
   notes/UPGRADE
   pyblosxom_cmd
   deploy_cgi
   deploy_paste
   deploy_wsgi
   deploy_staticrendering
   config_variables
   writing_entries
   flavours_and_templates
   syndication
   renderers
   comments
   plugins
   dev_architecture
   dev_writing_plugins
   dev_codedocs
   dev_testing
   notes/AUTHORS
   notes/THANKS
   glossary


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
