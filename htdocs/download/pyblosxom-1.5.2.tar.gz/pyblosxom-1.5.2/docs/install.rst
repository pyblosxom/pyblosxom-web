.. include:: ../INSTALL
