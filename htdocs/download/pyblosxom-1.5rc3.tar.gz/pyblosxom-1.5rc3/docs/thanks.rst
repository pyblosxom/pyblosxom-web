.. include:: ../THANKS
