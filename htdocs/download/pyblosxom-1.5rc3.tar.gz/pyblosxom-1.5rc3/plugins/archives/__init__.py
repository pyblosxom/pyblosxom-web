#######################################################################
# This file is part of PyBlosxom.
#
# Copyright (C) 2010 Will Kahn-Greene
#
# PyBlosxom is distributed under the MIT license.  See the file
# LICENSE for distribution details.
#######################################################################

"""
This is not a plugin.
"""
