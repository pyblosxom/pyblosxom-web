============
Introduction
============

This is the manual for PyBlosxom.  

This manual will always be free.  It's licensed under the MIT License
along with the rest of PyBlosxom.  The manual is version controlled along 
with the rest of PyBlosxom in the SVN repository at SourceForge.

This manual is a work in progress.  In many cases, missing information
is denoted with a *FIXME* in the text.

You can help us fix problems by sending in patches.  You can find us
on the mailing lists or IRC.  Details on contact information are in
the :ref:`project-details-and-contact`.

