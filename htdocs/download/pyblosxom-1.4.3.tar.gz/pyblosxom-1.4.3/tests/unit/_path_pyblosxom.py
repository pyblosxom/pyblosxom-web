import sys, os

testdir = os.path.join(os.path.dirname(__file__), "../../")
sys.path.insert(0, testdir)
