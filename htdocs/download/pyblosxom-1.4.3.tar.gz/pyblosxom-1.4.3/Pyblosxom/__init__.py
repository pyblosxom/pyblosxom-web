#######################################################################
# This file is part of PyBlosxom.
#
# Copyright (c) 2003, 2004, 2005, 2006 Wari Wahab
# 
# PyBlosxom is distributed under the MIT license.  See the file LICENSE
# for distribution details.
#
# $Id: __init__.py 913 2006-08-08 20:29:42Z willhelm $
#######################################################################
"""
This package holds PyBlosxom modules.
"""

__revision__ = "$Revision: 913 $"
