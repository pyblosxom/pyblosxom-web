1024px flavour was ported to Pyblosxom by Jennifer Ennis (http://foobar.us/~zaylea)
This flavour is based on an xhtml/css template by Andreas Viklund (http://www.andreasviklund.com).

For this flavour to work correctly, you need to move or create a symbolic
images/background.gif to a place that is accessible from the browser.
Next, you need to set in py['style_images'] the URL to the folder in which
background.gif is located (no trailing slash.)

i.e.: py['style_images'] = 'http://foobar.us/~zaylea/images'

This flavour has support for the comments, tags, nospam_captchasdotnet, and
pyarchives plugins. However, you will need to make some modifications to a few
files to enable it entirely. The files you need to modify for each plugin are
listed below. Read comments within the file to know what to edit. Below
is also the display related variables that you need to set in config.py for
each plugin.

For comments:
story.1024px

For tags:
story.1024px
py['pretext'] = 'tags: '
py['posttext'] = ''
py['tagsep'] = ' '

For nospam_captchasdotnet:
comment-form.1024px

For pyarchives:
foot.1024px
py['archive_template'] = '<li><a href="%(base_url)s/%(Y)s/%(b)s">%(b)s %(Y)s</a></li>'
